export interface IActivableDeactivateFunction<GReturn> {
  (): GReturn;
}
