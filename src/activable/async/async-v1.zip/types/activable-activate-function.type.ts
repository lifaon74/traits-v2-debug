export interface IActivableActivateFunction<GReturn> {
  (): GReturn;
}
