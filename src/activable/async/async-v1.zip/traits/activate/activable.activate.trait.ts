import { Trait } from '@lifaon/traits';

@Trait()
export abstract class ActivableActivateTrait<GSelf, GReturn> {
  abstract activate(this: GSelf): GReturn;
}


