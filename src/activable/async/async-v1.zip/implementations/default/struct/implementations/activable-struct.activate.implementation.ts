import { Impl } from '@lifaon/traits';
import { ActivableActivateTrait } from '../../../../traits/activate/activable.activate.trait';
import { ACTIVABLE_PRIVATE_CONTEXT, IActivablePrivateContext, IActivableStruct } from '../activable.struct';

@Impl()
export class ActivableStructActivateImplementation<GSelf extends IActivableStruct<GReturn>, GReturn> extends ActivableActivateTrait<GSelf, GReturn> {
  activate(this: GSelf): GReturn {
    const context: IActivablePrivateContext<GReturn> = this[ACTIVABLE_PRIVATE_CONTEXT];
    context.isActivated = true;
    return context.activate();
  }
}
