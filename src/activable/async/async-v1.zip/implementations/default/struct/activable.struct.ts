import { IActivableActivateFunction } from '../../../types/activable-activate-function.type';
import { IActivableDeactivateFunction } from '../../../types/activable-deactivate-function.type';

/** PRIVATE CONTEXT **/

export const ACTIVABLE_PRIVATE_CONTEXT: unique symbol = Symbol('activable-private-context');

export interface IActivablePrivateContext<GReturn> {
  isActivated: boolean;
  activate: IActivableActivateFunction<GReturn>;
  deactivate: IActivableDeactivateFunction<GReturn>;
}


/** STRUCT DEFINITION **/

export interface IActivableStruct<GReturn> {
  readonly [ACTIVABLE_PRIVATE_CONTEXT]: IActivablePrivateContext<GReturn>;
}

export type IGenericActivableStruct = IActivableStruct<unknown>;
